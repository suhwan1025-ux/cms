-- =====================================================
-- 계약관리시스템(CMS) - 초기 마스터 데이터 삽입
-- 파일명: 05_insert_master_data.sql
-- 실행: cms_admin 사용자로 contract_management DB에 연결하여 실행
-- 주의: 04_create_indexes.sql 실행 후 실행할 것
-- =====================================================

\c contract_management cms_admin

-- =====================================================
-- 1. 계약방식 마스터 데이터 (자산 등 구매업처리 규정 기반)
-- =====================================================
INSERT INTO contract_methods (value, name, regulation, description, is_active) VALUES
    ('CM04', '최저가 계약', '자산 등 구매업처리 규정 제4조 3항 - 제1항에도 불구하고 위임전결 규정 예산집행 전결 한도표에서 정의하는 본부장 이하 전결사항을 구매할 경우 계약부서 본부장의 승인을 받은 경우 2개처 이상의 공급업체로부터 계약금액을 제출받아 최저가 제출업체로 선정할 수 있다.', '최저가로 선정', TRUE),
    ('CM05', '경쟁계약(일반경쟁계약)', '자산 등 구매업처리 규정 제5조 1항 - 구매대상의 규격 및 시방서와 계약조건 등 계약의 내용을 널리 공고하여 일정한 자격을 가진 불특정 다수인의 입찰희망자를 참여시켜 경쟁입찰을 실시하는 계약방법', '일반경쟁입찰', TRUE),
    ('CM06', '경쟁계약(제한경쟁계약)', '자산 등 구매업처리 규정 제5조 2항 - 압찰참가자격을 실적, 기술보유현황, 필요설비 등 기타의 기준에 의해 입찰자격을 제한하여 당해 계약을 이행할 능력이 없는 자를 입찰에서 배제 시킴으로써 계약의 공개성 및 경제성을 유지시키는 계약 방법', '입찰자격 제한', TRUE),
    ('CM07', '경쟁계약(지명경쟁계약)', '자산 등 구매업처리 규정 제5조 3항 - 계약의 성질 또는 목적에 비추어 특수한 설비/기술/자재/물품 또는 실적이 있는 자가 아니면 계약목적을 달성하기 곤란한 경우 3개 이상의 업체를 선정하여 공문 등의 방법으로 지명통보를 하고 2개 업체 이상 응찰 시 성립되며, 대상 품목의 성격을 고려하여 최저가 낙찰 또는 평가를 통하여 최적의 낙찰자를 선정', '3개 이상 업체 지명', TRUE),
    ('CM08', '경쟁계약(협상에 의한 계약)', '자산 등 구매업처리 규정 제6조 - 당사에 필요한 최소한의 기술 및 지원사항 이 외 추가 적인 조건을 가격과 병행 평가하고자 하는 경우, 각 기술 및 지원사항의 장단점이 존재하는 경우 등의 평가에 사용하며 제한 또는 지명의 방식으로 입찰을 시행하고 적정한 비율에 의거 기술 및 가격평가를 실행하여 우선협상대상자 및 차상위 업체를 결정하고, 우선협상대상업체, 차상위 업체 순으로 추가적인 협상절차를 통하여 회사에 가장 유리하다고 인정되는 자와 계약을 체결', '기술+가격평가 후 협상', TRUE),
    ('CM10', '수의계약(제6조 제1항의 가)', '자산 등 구매업처리 규정 제6조 제1항의 가 - 천재지변, 긴급한 시설공사, 기타 이에 준하는 경우로서 경쟁에 부칠 여지가 없는 경우', '긴급한 경우', TRUE),
    ('CM11', '수의계약(제6조 제1항의 나)', '자산 등 구매업처리 규정 제6조 제1항의 나 - 계약의 목적을 비밀로 할 필요가 있는 경우', '비밀 유지 필요', TRUE),
    ('CM12', '수의계약(제6조 제1항의 다)', '자산 등 구매업처리 규정 제6조 제1항의 다 - 계약의 목적, 성질, 비용절감 또는 관리 효율성 등 수의계약에 의하는 것이 유리하거나 불가피하다고 인정될 경우', '수의계약이 유리한 경우', TRUE),
    ('CM13', '수의계약(제6조 제1항의 라)', '자산 등 구매업처리 규정 제6조 제1항의 라 - 그룹 통합 구매에 따라 진행하는 일괄 또는 통합 구매 품목일 경우', '그룹 통합 구매', TRUE),
    ('CM14', '수의계약(제6조 제1항의 마)', '자산 등 구매업처리 규정 제6조 제1항의 마 - 제4조제1항, 제4조제3항의 경우 재입찰에도 불구하고 단독입찰이 이루어진 경우로서 위임전결규정에 의한 전결권자가 승인한 경우', '단독입찰 승인', TRUE),
    ('CM15', '수의계약(제6조 제2항의 가)', '자산 등 구매업처리 규정 제6조 제2항의 가 - 특허를 받았거나 실용신안등록, 의장등록이 된 물품을 제조하게 하거나 매입하는 경우', '특허/실용신안 제품', TRUE),
    ('CM16', '수의계약(제6조 제2항의 나)', '자산 등 구매업처리 규정 제6조 제2항의 나 - 당해 물품의 생산자 또는 소지자가 1인뿐인 경우로서 다른 물품의 제조 또는 매입으로서는 사업목적을 달성할 수 없는 경우', '단독 생산자', TRUE),
    ('CM17', '수의계약(제6조 제2항의 다)', '자산 등 구매업처리 규정 제6조 제2항의 다 - 이미 조달된 물품의 부품교환, 설비확충 또는 증설을 위하여 조달하는 경우로서 해당 물품을 제조/공급한 자 외의 자로서는 제조/공급을 받게 되는 호환성이 없게 되는 경우', '호환성 유지', TRUE),
    ('CM18', '수의계약(제6조 제2항의 라)', '자산 등 구매업처리 규정 제6조 제2항의 라 - 특정인과 학술연구 등의 용역계약, 특정인의 기술/품질이나 경험 또는 자격을 필요로 하는 용역계약', '특정 기술/자격 필요', TRUE),
    ('CM19', '수의계약(제6조 제2항의 마)', '자산 등 구매업처리 규정 제6조 제2항의 마 - 용역의 제공이 주로 인력으로 이루어지는 계약으로 업무연속성 유지를 위한 용역 계약', '업무연속성 유지', TRUE),
    ('CM20', '수의계약(제6조 제2항의 바)', '자산 등 구매업처리 규정 제6조 제2항의 바 - 해당 물품을 제조/공급한 자가 직접 그 물품을 설치/조립/정비 또는 유지보수하는 경우', '제조사 직접 설치/유지보수', TRUE),
    ('CM21', '수의계약(제6조 제2항의 사)', '자산 등 구매업처리 규정 제6조 제2항의 사 - 특정 공급자가 제공하는 정보이용 계약으로 정보제공 연속성을 위한 서비스 이용계약', '정보제공 연속성', TRUE)
ON CONFLICT (value) DO NOTHING;

SELECT '✓ 계약방식 데이터 삽입 완료: ' || COUNT(*) || '개' FROM contract_methods;

-- =====================================================
-- 2. 결재조건 데이터
-- =====================================================
INSERT INTO approval_conditions (approver_id, condition_type, condition_value, condition_label) VALUES
    (1, 'contract_type', 'service', '용역계약'),
    (2, 'amount', 'over_50m', '계약금액 5천만원 초과'),
    (3, 'amount', 'over_2m', '계약금액 2백만원 초과'),
    (4, 'amount', '10m_300m', '계약금액 1천만원 초과 3억이하 본부장 전결')
ON CONFLICT DO NOTHING;

SELECT '✓ 결재조건 데이터 삽입 완료: ' || COUNT(*) || '개' FROM approval_conditions;

-- =====================================================
-- 3. 결재규칙 데이터
-- =====================================================
INSERT INTO approval_rules (rule_type, rule_name, rule_content, basis, is_active) VALUES
    ('amount', '💰 금액별 규칙', '["1천만원 이하: 담당자 (2백만원 초과 시 경영관리팀장)","1천만원 초과 ~ 5천만원 이하: 경영관리팀장","5천만원 초과 ~ 3억원 이하: 경영지원본부장","3억원 초과 ~ 50억원 이하: 경영지원실장"]', '예산집행 전결 한도표', TRUE),
    ('contract_type', '📋 계약유형별 규칙', '["용역계약: 준법감시인 필수 포함","구매계약: 일반 결재라인 적용","입찰계약: 일반 결재라인 적용","변경계약: 기존 결재라인 참조","연장계약: 기존 결재라인 참조"]', '내부통제 시행세칙 제 10조 1-11', TRUE),
    ('audit', '🔍 감사 규칙', '["계약금액 1천만원 초과: IT 내부감사인 포함","계약금액 5천만원 이상: 감사본부장 포함","IT본부장 전결: 천만원 이상~3억원 이하 구매/계약"]', 'IT자체감사 지침 제 10조[감사 실시] 7', TRUE)
ON CONFLICT DO NOTHING;

SELECT '✓ 결재규칙 데이터 삽입 완료: ' || COUNT(*) || '개' FROM approval_rules;

-- =====================================================
-- 4. 결재참조표 데이터
-- =====================================================
INSERT INTO approval_references (amount_range, min_amount, max_amount, included_approvers, final_approver, description, is_active) VALUES
    ('1천만원 이하', 0, 10000000.00, '경영관리팀장 (2백만원 초과 시)', '팀장', NULL, TRUE),
    ('1천만원 초과 ~ 5천만원 이하', 10000000.00, 50000000.00, 'IT내부감사인, 경영관리팀장', '본부장', NULL, TRUE),
    ('5천만원 초과 ~ 3억원 이하', 50000000.00, 300000000.00, 'IT내부감사인, 경영지원본부장, 감사본부장', '본부장', NULL, TRUE),
    ('3억원 초과 ~ 50억원 이하', 300000000.00, 5000000000.00, '경영지원실장, 감사본부장', '대표이사', NULL, TRUE)
ON CONFLICT DO NOTHING;

SELECT '✓ 결재참조표 데이터 삽입 완료: ' || COUNT(*) || '개' FROM approval_references;

-- =====================================================
-- 5. 문서 템플릿 데이터
-- =====================================================
INSERT INTO document_templates (name, description, content, category, is_active, display_order, created_by) VALUES
    ('추진품의', '사업 추진을 위한 품의서 템플릿', '<h1 style="text-align:center;">사업 추진 품의서</h1><h2>1. 추진 개요</h2><figure class="table"><table><tbody><tr><th style="background-color:#f8f9fa;width:150px;">사업명</th><td>[사업명을 입력하세요]</td></tr><tr><th style="background-color:#f8f9fa;">추진 목적</th><td>[추진 목적을 입력하세요]</td></tr><tr><th style="background-color:#f8f9fa;">추진 기간</th><td>[시작일] ~ [종료일]</td></tr><tr><th style="background-color:#f8f9fa;">담당 부서</th><td>[담당 부서명]</td></tr></tbody></table></figure><h2>2. 추진 배경</h2><p>[추진 배경 및 필요성을 기술하세요]</p><h2>3. 추진 내용</h2><ul><li data-list-item-id="e0cb95b5619fa3c66d3a93d11f5d9760b"><strong>주요 업무:</strong> [주요 업무 내용]</li><li data-list-item-id="e00715d8c899cdfd6576bb2eefaf0f0bc"><strong>예상 성과:</strong> [예상되는 성과]</li><li data-list-item-id="ee29a8e7670de6ed83d59c0c558be10c6"><strong>위험 요소:</strong> [예상 위험 요소 및 대응방안]</li></ul><h2>4. 소요 예산</h2><figure class="table"><table><thead><tr><th style="background-color:#f8f9fa;">항목</th><th style="background-color:#f8f9fa;">금액</th><th style="background-color:#f8f9fa;">비고</th></tr><tr><th style="background-color:#f8f9fa;">합계</th><th>[총 금액]</th><th>&nbsp;</th></tr></thead><tbody><tr><td>[예산 항목 1]</td><td>[금액]</td><td>[비고]</td></tr><tr><td>[예산 항목 2]</td><td>[금액]</td><td>[비고]</td></tr></tbody></table></figure><h2>5. 추진 일정</h2><figure class="table"><table><thead><tr><th style="background-color:#f8f9fa;">단계</th><th style="background-color:#f8f9fa;">기간</th><th style="background-color:#f8f9fa;">주요 활동</th></tr></thead><tbody><tr><td>1단계</td><td>[기간]</td><td>[주요 활동]</td></tr><tr><td>2단계</td><td>[기간]</td><td>[주요 활동]</td></tr></tbody></table></figure><p><strong>검토 의견:</strong></p><p>위와 같이 추진하고자 하오니 검토 후 승인하여 주시기 바랍니다.</p>', 'general', TRUE, 1, '시스템'),
    ('입찰 실시 품의서(표준)', '표준 입찰 실시 품의서 템플릿 (SOR, GPU, 차세대 주전산기 사례 기반)', '
      <div style="text-align: center; margin-bottom: 30px;">
        <h1>입찰 실시 품의서</h1>
      </div>

     
      <p style="margin: 30px 0 20px 0;">「[프로젝트명]」 수행업체 선정을 위해 아래와 같이 입찰을 실시하고자 하오니 재가하여 주시기 바랍니다.</p>

      <p style="text-align: center; font-weight: bold; margin: 30px 0;">- 아&nbsp;&nbsp;&nbsp;래 -</p>

      <h2>1. 목 적</h2>
      <p>[프로젝트의 핵심 목표를 간결하게 기술합니다.]</p>
      <p><em>예: 노후화된 고객상담시스템 교체 및 신규 비즈니스 지원 체계 구축</em></p>
      <ul>
        <li>[세부 목적 1]</li>
        <li>[세부 목적 2]</li>
        <li>[세부 목적 3]</li>
      </ul>

      <h2>2. 근 거</h2>
      <ul>
        <li>(추진기안) [문서번호] [관련 기안 제목]</li>
        <li>(협조전) [문서번호] [관련 협조전 제목]</li>
        <li>[기타 관련 문서]</li>
      </ul>

      <h2>3. 사업 예산</h2>
      <p><strong>총 [총예산 금액] 원 (VAT 포함)</strong></p>

      <h2>4. 입찰 및 계약 방식</h2>
      <ul>
        <li><strong>입찰 방식:</strong> [제한경쟁입찰 / 지명경쟁입찰 / 일반경쟁입찰 중 선택]</li>
        <li><strong>공고/통보 방식:</strong> [홈페이지 공고 / 지명 업체 공문 통보 등]</li>
        <li><strong>선정 방식:</strong> [업체 선정 방식 기술]
          <ul>
            <li>예시1: 기술평가 및 가격평가를 통한 우선협상대상자 선정</li>
            <li>예시2: 최저가 낙찰</li>
          </ul>
        </li>
        <li><strong>지명/제한 사유 (해당 시):</strong><br>
          [지명 또는 제한 경쟁을 하는 이유를 관련 규정에 근거하여 작성합니다.]<br>
          <em>예시: 계약의 성격상 특수한 기술이 필요하며, 국내 공식 총판을 통해서만 공급이 가능함</em>
        </li>
      </ul>

      <h2>5. 입찰 참가 자격</h2>
      <ul>
        <li>국가기관, 지방자치단체 등의 부적격 업체로 제재받고 있지 아니한 사업자</li>
        <li>업체 및 대표자가 은행연합회 불량거래처 등으로 등재되어 있지 아니한 사업자</li>
        <li>최근 [N년] 이내 [유사 사업 분야] 구축 실적을 보유한 사업자</li>
        <li>제조사의 ''물품공급 및 기술지원 확약서'' 제출이 가능한 사업자</li>
        <li>[기타 프로젝트 특성에 따른 자격 요건 추가]</li>
      </ul>

      <h2>6. 입찰 대상</h2>
      <figure class="table">
        <table style="width: 100%; border-collapse: collapse;">
          <thead>
            <tr>
              <th style="background-color: #f8f9fa; padding: 10px; border: 1px solid #ddd;">구분</th>
              <th style="background-color: #f8f9fa; padding: 10px; border: 1px solid #ddd;">항목</th>
              <th style="background-color: #f8f9fa; padding: 10px; border: 1px solid #ddd;">수량</th>
              <th style="background-color: #f8f9fa; padding: 10px; border: 1px solid #ddd;">상세 내역</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td style="padding: 8px; border: 1px solid #ddd;">H/W</td>
              <td style="padding: 8px; border: 1px solid #ddd;">[예: GPU 서버]</td>
              <td style="padding: 8px; border: 1px solid #ddd;">[예: 2대]</td>
              <td style="padding: 8px; border: 1px solid #ddd;">[세부 모델명 또는 사양 기술, 예: B200]</td>
            </tr>
            <tr>
              <td style="padding: 8px; border: 1px solid #ddd;">S/W</td>
              <td style="padding: 8px; border: 1px solid #ddd;">[예: 상담 앱]</td>
              <td style="padding: 8px; border: 1px solid #ddd;">[예: 50식]</td>
              <td style="padding: 8px; border: 1px solid #ddd;">[주요 기능 등 기술]</td>
            </tr>
            <tr>
              <td style="padding: 8px; border: 1px solid #ddd;">기술지원</td>
              <td style="padding: 8px; border: 1px solid #ddd;">유지보수 및 기술지원</td>
              <td style="padding: 8px; border: 1px solid #ddd;">1식</td>
              <td style="padding: 8px; border: 1px solid #ddd;">[내용 요약]</td>
            </tr>
            <tr style="font-weight: bold;">
              <td style="padding: 8px; border: 1px solid #ddd; background-color: #f8f9fa;">합계</td>
              <td style="padding: 8px; border: 1px solid #ddd; background-color: #f8f9fa;">-</td>
              <td style="padding: 8px; border: 1px solid #ddd; background-color: #f8f9fa;">-</td>
              <td style="padding: 8px; border: 1px solid #ddd; background-color: #f8f9fa;">-</td>
            </tr>
          </tbody>
        </table>
      </figure>
      <p><em>※ 상세 내역은 ''제안요청서'' 참조</em></p>

      <h2>7. 평가 기준</h2>
      <ul>
        <li><strong>평가 방식:</strong> 기술평가( [배점] %) + 가격평가( [배점] %)</li>
        <li><em>예시: 기술평가 80% + 가격평가 20%</em></li>
        <li><strong>세부 사항:</strong> 기술평가 세부항목 및 배점은 첨부된 ''기술평가표'' 참조</li>
      </ul>

      <h2>8. 추진 일정</h2>
      <figure class="table">
        <table style="width: 100%; border-collapse: collapse;">
          <thead>
            <tr>
              <th style="background-color: #f8f9fa; padding: 10px; border: 1px solid #ddd;">추진 단계</th>
              <th style="background-color: #f8f9fa; padding: 10px; border: 1px solid #ddd;">일정</th>
              <th style="background-color: #f8f9fa; padding: 10px; border: 1px solid #ddd;">예상 일자</th>
              <th style="background-color: #f8f9fa; padding: 10px; border: 1px solid #ddd;">비고</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td style="padding: 8px; border: 1px solid #ddd;">입찰 공고</td>
              <td style="padding: 8px; border: 1px solid #ddd;">D-Day</td>
              <td style="padding: 8px; border: 1px solid #ddd;">[YYYY-MM-DD]</td>
              <td style="padding: 8px; border: 1px solid #ddd;">홈페이지 공고</td>
            </tr>
            <tr>
              <td style="padding: 8px; border: 1px solid #ddd;">입찰 마감</td>
              <td style="padding: 8px; border: 1px solid #ddd;">D + [N]일</td>
              <td style="padding: 8px; border: 1px solid #ddd;">[YYYY-MM-DD]</td>
              <td style="padding: 8px; border: 1px solid #ddd;">방문 또는 우편 접수</td>
            </tr>
            <tr>
              <td style="padding: 8px; border: 1px solid #ddd;">제안 설명회 (필요시)</td>
              <td style="padding: 8px; border: 1px solid #ddd;">D + [N]일</td>
              <td style="padding: 8px; border: 1px solid #ddd;">[YYYY-MM-DD]</td>
              <td style="padding: 8px; border: 1px solid #ddd;">본사 26F</td>
            </tr>
            <tr>
              <td style="padding: 8px; border: 1px solid #ddd;">기술/가격 평가</td>
              <td style="padding: 8px; border: 1px solid #ddd;">D + [N]일</td>
              <td style="padding: 8px; border: 1px solid #ddd;">[YYYY-MM-DD]</td>
              <td style="padding: 8px; border: 1px solid #ddd;">우선협상대상자 선정</td>
            </tr>
            <tr>
              <td style="padding: 8px; border: 1px solid #ddd;">계약 체결</td>
              <td style="padding: 8px; border: 1px solid #ddd;">D + [N]일</td>
              <td style="padding: 8px; border: 1px solid #ddd;">[YYYY-MM-DD] ~</td>
              <td style="padding: 8px; border: 1px solid #ddd;"></td>
            </tr>
          </tbody>
        </table>
      </figure>


    ', 'bidding', TRUE, 2, '시스템'),
    ('입찰 결과 보고 품의', '입찰 결과 보고를 위한 품의서 템플릿', '
      <h1>입찰 결과 보고 품의서</h1>
      
      <h2>1. 입찰 개요</h2>
      <table>
        <tr>
          <th style="width: 150px; background-color: #f8f9fa;">입찰명</th>
          <td>[입찰 사업명]</td>
        </tr>
        <tr>
          <th style="background-color: #f8f9fa;">공고일</th>
          <td>[입찰 공고일]</td>
        </tr>
        <tr>
          <th style="background-color: #f8f9fa;">개찰일</th>
          <td>[입찰 개찰일]</td>
        </tr>
        <tr>
          <th style="background-color: #f8f9fa;">추정 가격</th>
          <td>[추정 가격] 원</td>
        </tr>
      </table>

      <h2>2. 입찰 참가 현황</h2>
      <table>
        <tr>
          <th style="background-color: #f8f9fa;">구분</th>
          <th style="background-color: #f8f9fa;">업체 수</th>
          <th style="background-color: #f8f9fa;">비고</th>
        </tr>
        <tr>
          <td>입찰 참가 업체</td>
          <td>[참가 업체 수]개 업체</td>
          <td></td>
        </tr>
        <tr>
          <td>유효 입찰</td>
          <td>[유효 입찰 수]개 업체</td>
          <td></td>
        </tr>
        <tr>
          <td>무효 입찰</td>
          <td>[무효 입찰 수]개 업체</td>
          <td>[무효 사유]</td>
        </tr>
      </table>

      <h2>3. 입찰 결과</h2>
      <table>
        <tr>
          <th style="background-color: #f8f9fa;">순위</th>
          <th style="background-color: #f8f9fa;">업체명</th>
          <th style="background-color: #f8f9fa;">입찰금액</th>
          <th style="background-color: #f8f9fa;">낙찰률</th>
          <th style="background-color: #f8f9fa;">비고</th>
        </tr>
        <tr>
          <td>1위</td>
          <td>[낙찰업체명]</td>
          <td>[낙찰금액] 원</td>
          <td>[낙찰률]%</td>
          <td>낙찰</td>
        </tr>
        <tr>
          <td>2위</td>
          <td>[업체명]</td>
          <td>[입찰금액] 원</td>
          <td>[비율]%</td>
          <td></td>
        </tr>
        <tr>
          <td>3위</td>
          <td>[업체명]</td>
          <td>[입찰금액] 원</td>
          <td>[비율]%</td>
          <td></td>
        </tr>
      </table>

      <h2>4. 낙찰자 선정 사유</h2>
      <p>[낙찰자 선정 근거와 사유를 상세히 기술하세요]</p>
      
      <ul>
        <li><strong>가격 경쟁력:</strong> [가격 관련 평가]</li>
        <li><strong>기술 능력:</strong> [기술적 우수성]</li>
        <li><strong>업체 신뢰도:</strong> [과거 실적 및 신뢰도]</li>
        <li><strong>기타 고려사항:</strong> [추가 고려사항]</li>
      </ul>

      <h2>5. 계약 조건</h2>
      <table>
        <tr>
          <th style="background-color: #f8f9fa;">항목</th>
          <th style="background-color: #f8f9fa;">내용</th>
        </tr>
        <tr>
          <td>계약금액</td>
          <td>[계약금액] 원 (부가세 포함)</td>
        </tr>
        <tr>
          <td>계약기간</td>
          <td>[계약 시작일] ~ [계약 종료일]</td>
        </tr>
        <tr>
          <td>납품일정</td>
          <td>[납품 예정일]</td>
        </tr>
        <tr>
          <td>지급조건</td>
          <td>[대금 지급 조건]</td>
        </tr>
      </table>

      <h2>6. 향후 일정</h2>
      <ul>
        <li><strong>계약 체결:</strong> [계약 예정일]</li>
        <li><strong>사업 착수:</strong> [착수 예정일]</li>
        <li><strong>완료 예정:</strong> [완료 예정일]</li>
      </ul>

      <p><strong>결론:</strong></p>
      <p>위와 같이 입찰을 실시한 결과 [낙찰업체명]을 낙찰자로 선정하였으니 검토 후 계약 체결을 승인하여 주시기 바랍니다.</p>
    ', 'bidding', TRUE, 3, '시스템')
ON CONFLICT DO NOTHING;

SELECT '✓ 문서 템플릿 데이터 삽입 완료: ' || COUNT(*) || '개' FROM document_templates;

-- =====================================================
-- 완료 요약
-- =====================================================
SELECT 
    '==========================================' AS separator
UNION ALL
SELECT '  초기 마스터 데이터 삽입 완료'
UNION ALL
SELECT '==========================================' 
UNION ALL
SELECT '계약방식: ' || (SELECT COUNT(*)::text FROM contract_methods) || '개'
UNION ALL
SELECT '결재규칙: ' || (SELECT COUNT(*)::text FROM approval_rules) || '개'
UNION ALL
SELECT '문서 템플릿: ' || (SELECT COUNT(*)::text FROM document_templates) || '개'
UNION ALL
SELECT '==========================================';
